package com.allblue.protocol

import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "All Blue Protocol"
        val body = intent.getStringExtra("body") ?: "Your scheduled task is due."
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("tasks", "Task reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, "tasks")
        else @Suppress("DEPRECATION") Notification.Builder(context)
        manager.notify(intent.getIntExtra("id", 1), notification.setContentTitle(title)
            .setContentText(body).setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build())
    }
}
