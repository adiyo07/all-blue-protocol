package com.allblue.protocol

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF14233A)
private val Blue = Color(0xFF5799FF)
private val Muted = Color(0xFF9AABC5)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("all_blue_local", MODE_PRIVATE) }
    private var exportJson: String = "{}"
    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { contentResolver.openOutputStream(it)?.use { stream -> stream.write(exportJson.toByteArray()) } }
    }
    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { contentResolver.openInputStream(it)?.bufferedReader()?.use { reader ->
            runCatching { prefs.edit().putString("data", reader.readText()).apply() }
        } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 20)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel)) {
                Surface(Modifier.fillMaxSize(), color = Navy) {
                    AppRoot(
                        prefs = prefs,
                        onBackup = {
                            exportJson = prefs.getString("data", "{}") ?: "{}"
                            createBackup.launch("all-blue-protocol-backup.json")
                        },
                        onRestore = { openBackup.launch(arrayOf("application/json")) },
                        onReminder = { title, desc, hour, minute, id -> scheduleReminder(title, desc, hour, minute, id) }
                    )
                }
            }
        }
    }

    private fun scheduleReminder(title: String, desc: String, hour: Int, minute: Int, id: Int) {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("title", title); putExtra("body", desc); putExtra("id", id)
        }
        val pi = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        runCatching { alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
            .onFailure { alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
    }
}

private fun hash(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

private data class Task(val title: String, val detail: String, val done: Boolean = false, val hour: Int = -1, val minute: Int = -1)
private val characters = listOf("Monkey D. Luffy", "Roronoa Zoro", "Sanji", "Shanks", "Monkey D. Garp", "Eustass Kid", "Portgas D. Ace", "Trafalgar Law", "Sabo", "Dracule Mihawk", "Jinbe", "Nami", "Nico Robin", "Usopp", "Tony Tony Chopper", "Franky", "Brook", "Yamato", "Boa Hancock", "Koby", "Smoker", "Marco", "Katakuri", "Killer", "Benn Beckman")
private val symbols = mapOf("Monkey D. Luffy" to "☠️", "Roronoa Zoro" to "⚔️", "Sanji" to "🔥", "Shanks" to "🟥", "Monkey D. Garp" to "⚓", "Eustass Kid" to "🦾", "Portgas D. Ace" to "🔥", "Trafalgar Law" to "✚", "Sabo" to "🎩", "Dracule Mihawk" to "🗡️", "Jinbe" to "🌊", "Nami" to "⚡", "Nico Robin" to "🌸", "Usopp" to "🎯", "Tony Tony Chopper" to "🦌", "Franky" to "🤖", "Brook" to "🎸", "Yamato" to "🐉")

@Composable
private fun AppRoot(prefs: android.content.SharedPreferences, onBackup: () -> Unit, onRestore: () -> Unit, onReminder: (String,String,Int,Int,Int)->Unit) {
    var raw by remember { mutableStateOf(prefs.getString("data", "{}") ?: "{}") }
    fun obj() = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    fun persist(o: JSONObject) { raw = o.toString(); prefs.edit().putString("data", raw).apply() }
    var logged by remember { mutableStateOf(prefs.getBoolean("logged", false) && obj().optString("username").isNotBlank()) }
    var signup by remember { mutableStateOf(!logged) }
    var page by remember { mutableStateOf("Home") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(characters.first()) }
    var taskTitle by remember { mutableStateOf("") }
    var taskDetail by remember { mutableStateOf("") }
    var reminderHour by remember { mutableStateOf("") }
    var reminderMinute by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val state = obj()
    val taskArray = state.optJSONArray("tasks") ?: JSONArray()
    val tasks = (0 until taskArray.length()).mapNotNull { i -> runCatching {
        val t = taskArray.getJSONObject(i); Task(t.optString("title"),t.optString("detail"),t.optBoolean("done"),t.optInt("hour",-1),t.optInt("minute",-1))
    }.getOrNull() }
    fun saveTasks(list: List<Task>) { val o=obj(); val a=JSONArray(); list.forEach { t -> a.put(JSONObject().put("title",t.title).put("detail",t.detail).put("done",t.done).put("hour",t.hour).put("minute",t.minute)) }; o.put("tasks",a); persist(o); refresh++ }

    if (!logged) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement=Arrangement.Center) {
            Text("ALL BLUE PROTOCOL", color=Color.White, fontSize=27.sp, fontWeight=FontWeight.Black)
            Text("YOUR PERSONAL LIFE SYSTEM", color=Blue, fontSize=11.sp)
            Spacer(Modifier.height(24.dp))
            Text(if (signup) "Create your account" else "Welcome back", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
            OutlinedTextField(username,{username=it},label={Text("Username")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(password,{password=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())
            if (signup) {
                Text("Choose your character — the app assigns and locks your profile avatar.", color=Muted, modifier=Modifier.padding(top=14.dp))
                LazyColumn(Modifier.height(210.dp)) {
                    items(characters) { c ->
                        Row(Modifier.fillMaxWidth().clickable { selected=c }.padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                            Text(symbols[c] ?: "⭐", fontSize=22.sp); Spacer(Modifier.width(12.dp))
                            Text(c, color=Color.White, modifier=Modifier.weight(1f))
                            RadioButton(selected==c,{selected=c})
                        }
                    }
                }
            }
            Button(onClick={
                if(username.trim().length>=3 && password.length>=6) {
                    if(signup && state.optString("username").isBlank()) {
                        val o=obj().put("username",username.trim()).put("passwordHash",hash(password)).put("character",selected).put("tasks",JSONArray()).put("habits",JSONArray()).put("activities",JSONArray())
                        persist(o); prefs.edit().putBoolean("logged",true).apply(); logged=true
                    } else if(!signup && state.optString("username")==username.trim() && state.optString("passwordHash")==hash(password)) { prefs.edit().putBoolean("logged",true).apply(); logged=true }
                }
            }, modifier=Modifier.fillMaxWidth().padding(top=16.dp)) { Text(if(signup) "Create account" else "Sign in") }
            TextButton(onClick={signup=!signup}) { Text(if(signup) "Already registered? Sign in" else "Create a local account") }
            Text("Local account: stored on this phone. It is not cloud authentication.", color=Muted, fontSize=11.sp)
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(18.dp)) {
            Text("ALL BLUE PROTOCOL", color=Blue, fontSize=11.sp, fontWeight=FontWeight.Bold)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(symbols[state.optString("character")] ?: "⭐", fontSize=34.sp)
                Spacer(Modifier.width(10.dp))
                Column { Text("Welcome, ${state.optString("username")}", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold); Text(state.optString("character"), color=Muted, fontSize=12.sp) }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=10.dp)) {
            listOf("Home","Tasks","Activities","Habits","Profile").forEach { item ->
                TextButton(onClick={page=item}) { Text(item, color=if(page==item) Blue else Muted) }
            }
        }
        when(page) {
            "Home" -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("Your All Blue journey", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                Text("${tasks.count{it.done}} of ${tasks.size} tasks completed", color=Muted)
                Spacer(Modifier.height(12.dp))
                Card(colors=CardDefaults.cardColors(containerColor=Panel)) { Column(Modifier.padding(16.dp)) {
                    Text("TODAY'S FOCUS", color=Blue, fontSize=12.sp); Text("Small steps. Long voyage.", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold)
                } }
                Spacer(Modifier.height(14.dp)); Text("Upcoming tasks", color=Color.White, fontWeight=FontWeight.Bold)
                tasks.take(5).forEach { Text((if(it.done) "✓ " else "○ ")+it.title, color=Muted, modifier=Modifier.padding(6.dp)) }
            }
            "Tasks" -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("Task planner", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                OutlinedTextField(taskTitle,{taskTitle=it},label={Text("Task name")},modifier=Modifier.fillMaxWidth())
                OutlinedTextField(taskDetail,{taskDetail=it},label={Text("Details (optional)")},modifier=Modifier.fillMaxWidth())
                Text("Optional reminder (24-hour time)", color=Muted, fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(reminderHour,{reminderHour=it.filter(Char::isDigit).take(2)},label={Text("Hour 0–23")},modifier=Modifier.weight(1f), singleLine=true)
                    OutlinedTextField(reminderMinute,{reminderMinute=it.filter(Char::isDigit).take(2)},label={Text("Minute 0–59")},modifier=Modifier.weight(1f), singleLine=true)
                }
                Button(onClick={ if(taskTitle.isNotBlank()){
                    val h=reminderHour.toIntOrNull() ?: -1; val m=reminderMinute.toIntOrNull() ?: -1
                    val valid=(h in 0..23 && m in 0..59)
                    val newTask=Task(taskTitle.trim(),taskDetail.trim(),false,if(valid) h else -1,if(valid) m else -1)
                    saveTasks(tasks+newTask)
                    if(valid) onReminder(newTask.title,newTask.detail,h,m,tasks.size+100)
                    taskTitle="";taskDetail="";reminderHour="";reminderMinute=""
                } }, modifier=Modifier.fillMaxWidth()) { Text("Add task & schedule reminder") }
                tasks.forEachIndexed { i,t ->
                    Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(containerColor=Panel)) {
                        Row(Modifier.padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(t.done,{v->saveTasks(tasks.mapIndexed{j,x->if(i==j)x.copy(done=v) else x})})
                            Column(Modifier.weight(1f)) {
                                Text(t.title,color=Color.White)
                                if(t.detail.isNotBlank()) Text(t.detail,color=Muted,fontSize=12.sp)
                                if(t.hour>=0) Text("Reminder ${"%02d:%02d".format(t.hour,t.minute)}",color=Blue,fontSize=11.sp)
                            }
                            TextButton(onClick={saveTasks(tasks.filterIndexed{j,_->j!=i})}) { Text("Delete") }
                        }
                    }
                }
            }
            "Activities" -> Column(Modifier.padding(16.dp)) {
                Text("Activity tracker", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                Text("Use tasks for workouts, study sessions, reading, chores and personal goals. Completed tasks remain in your records only while not deleted.", color=Muted)
            }
            "Habits" -> Column(Modifier.padding(16.dp)) {
                Text("Daily habits", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                listOf("Morning routine","Study / learning","Movement","Balanced meals","Hydration","Sleep routine").forEach { habit ->
                    var checked by remember { mutableStateOf(false) }
                    Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(checked,{checked=it}); Text(habit,color=Color.White) }
                }
                Text("Habit checkmarks in this starter version reset when the app screen is recreated; persistent habit history is a planned next build.", color=Muted, fontSize=12.sp)
            }
            else -> Column(Modifier.padding(16.dp)) {
                Text("Profile & backup", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                Text("Character: ${state.optString("character")}", color=Muted)
                Text("Your assigned avatar is locked to your character selection.", color=Muted)
                Spacer(Modifier.height(12.dp))
                Button(onClick=onBackup, modifier=Modifier.fillMaxWidth()) { Text("Export backup") }
                OutlinedButton(onClick=onRestore, modifier=Modifier.fillMaxWidth()) { Text("Restore backup") }
                TextButton(onClick={prefs.edit().putBoolean("logged",false).apply();logged=false;signup=false}) { Text("Sign out") }
                Text("This is a local profile, not a server account. Keep your backup file safe. Password recovery is not available.", color=Muted, fontSize=12.sp)
            }
        }
    }
}
